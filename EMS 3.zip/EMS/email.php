<?php
    mail('mattking971@yahoo.com', $_POST['PatientList'], $_POST['comment'], $_POST['serviceCost'], $_POST['insurance'], $_POST['output']);
    ?>
<p>Above is outlining your visit today. Please make sure to come by the office to pay the subtotal in cash or check. Thank You</p>
